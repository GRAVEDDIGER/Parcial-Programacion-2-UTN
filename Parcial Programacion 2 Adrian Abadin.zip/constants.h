#pragma once
const char* VIAJES = "Viajes.dat";
const char* TARJETAS = "Tarjetas.dat";