#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <locale.h>
#include "functions.h"
#include "Viajes.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "");
    menu();
    return 0;
}
