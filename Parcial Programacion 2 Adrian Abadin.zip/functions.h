#include <iostream>
#pragma once

int longitudArchivo(FILE* data);
void numeroDeViajes(char* tarjeta);
void viajeMenorImporte();
void subteMayorRecaudacion();
int contarViajesColectivo(char* numeroTarjeta);
void viajesXTarjeta();
void mostrarDatosTarjeta(char* numeroTarjeta, int importe);
void viajeMayorImporte();
int importeTotalTarjeta(char* numeroTarjeta);
void importesTarjetasActivas();
void menu();